package com.kaksha.ds;

public class RBTTest {

	public static void main(String[] args) {
		BST<Integer, String> bst = new BST<>();
		bst.insert(10, null);
		bst.insert(9, null);
		bst.insert(8, null);
		bst.insert(7, null);
		bst.insert(6, null);
		bst.insert(5, null);
		bst.insert(4, null);
		bst.insert(3, null);
		bst.insert(2, null);
		bst.insert(1, null);
		bst.insert(0, null);

		bst.inOrder();
		System.out.println("height = " + bst.height()); // height is N

		RBT<Integer, String> rbt = new RBT<>();
		rbt.insert(10, null);
		rbt.insert(9, null);
		rbt.insert(8, null);
		rbt.insert(7, null);
		rbt.insert(6, null);
		rbt.insert(5, null);
		rbt.insert(4, null);
		rbt.insert(3, null);
		rbt.insert(2, null);
		rbt.insert(1, null);
		rbt.insert(0, null);

		rbt.inOrder();
		System.out.println("height = " + rbt.height()); // height should be log n
	}
}
